# Advanced Road Accident Severity System

## Features
- CNN Model
- Flask UI
- Hospital Recommendation
- Alert System (Twilio)
- Google Maps Integration (placeholder)

## Run
pip install -r requirements.txt
python app.py
