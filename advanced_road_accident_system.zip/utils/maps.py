def get_nearby_hospitals(lat, lon):
    return ["Apollo Hospital", "Yashoda Hospital"]
