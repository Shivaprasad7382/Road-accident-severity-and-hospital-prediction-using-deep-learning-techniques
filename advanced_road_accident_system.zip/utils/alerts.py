def send_alert():
    print("Alert sent to ambulance and relatives")
