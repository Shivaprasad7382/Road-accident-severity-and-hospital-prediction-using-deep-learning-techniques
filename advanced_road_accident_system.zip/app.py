from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np

app = Flask(__name__)

def dummy_cnn_predict(frame):
    return "Severe" if np.mean(frame) > 120 else "Minor"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    npimg = np.frombuffer(file.read(), np.uint8)
    frame = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
    result = dummy_cnn_predict(frame)
    return jsonify({"severity": result})

@app.route('/hospitals')
def hospitals():
    data = [
        {"name": "Apollo Hospital", "location": "Hyderabad"},
        {"name": "Yashoda Hospital", "location": "Hyderabad"}
    ]
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
